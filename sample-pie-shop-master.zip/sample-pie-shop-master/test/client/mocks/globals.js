import fbMock from '../../mocks/firebase-mock';

window.firebase = fbMock;
